import { Component } from '@angular/core';

@Component({
  selector: 'app-salario-var',
  standalone: true,
  imports: [],
  templateUrl: './salario-var.component.html',
  styleUrl: './salario-var.component.css'
})
export class SalarioVarComponent {

}
